package mEthodOverLoading;			//compile time polymorphism

import java.util.Scanner;

class Load{
	public void add(int a, int b) {
		int c = a + b;
		System.out.println("Addition value is : " + c);
	}
	public void add(int a, int b, int c) {
		int d = a * b * c;
		
		System.out.println("multiple value is : " + d);
	}
}

public class mEthodOverLoading {

	public static void main(String[] args) {
		Load l = new Load();
		l.add(1, 2);
		l.add(2, 2, 3);

	}

}
