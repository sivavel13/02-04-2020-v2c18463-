package mEthodOverRiding;

class admin{  																		//parent class
	public void adminEntry() {
		System.out.println("Reminder the admin .. :) ");
	}
}

class student extends professor{														//child class - 1

	public void adminEntry() {
		System.out.println("All subject you got pass marks");
	}
}

class professor extends admin{														//child class - 2

//	public void adminEntry() {
//		System.out.println("Your next lesson Intgration");
//	}
}

public class mEthodOverRiding {

	public static void main(String[] args) {

		student s = new student();
		s.adminEntry();
		
		professor p = new professor();
		p.adminEntry();
	}

}


